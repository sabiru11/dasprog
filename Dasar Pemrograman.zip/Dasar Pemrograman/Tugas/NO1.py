n = int(input("Input: "))

for i in range(1, n + 1):
    if i % 10 == 0:
        print("boom", end=" ")
    elif i % 2 == 0:
        print("tpl", end=" ")
    else:
        print(i, end=" ")