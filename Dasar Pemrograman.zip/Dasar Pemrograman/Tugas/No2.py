barang = []
jumlah = []
harga = []

barang.append(input("Barang: "))
jumlah.append(int(input("Jumlah: ")))
harga.append(int(input('Harga: ')))
 
print("Daftar Belanja:")

total = 0

for i in range(len(barang)):
    print(barang[i], "-", jumlah[i], "pcs - Rp", harga[i])
    total =  jumlah[i] * harga[i]

print("Total Belanja = Rp", total)

barang.clear()
jumlah.clear()
harga.clear()

print("Checkout berhasil.")
print("Barang:", barang)
print("Jumlah:", jumlah)
print("Harga:", harga)