kalimat = input("Input: ")

for huruf in "abcdefghijklmnopqrstuvwxyz":
    jumlah = kalimat.lower().count(huruf)
    if jumlah > 0:
        print(huruf, "=", jumlah)