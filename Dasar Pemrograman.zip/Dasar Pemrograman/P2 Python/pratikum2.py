a, b = 10, 15
print(a, '+', b, '=', a + b)
print(a, '-', b, '=', a-b )
print(a, '*', b, '=', a*b )

print(a, '>', b, '=', a > b)
print(a, '<', b, '=', a < b )
print(a, '==', b, '=', a == b)

perusahaan = 'unilever'
list_kota = ['jakarta' 'bandung' 'bogor']

print(
    "'n' ada di variabel perusahaan",
    'n' in perusahaan
)
print(
    "'t' tidak ada di variabel perusahaan",
    't' not in perusahaan
)
print(
    "'u' tidak ada di variabel perusahaan",
    'u' not in perusahaan
)
a = 7 
b = 7 
c = 2 
d = 5
list_a = [7,8,9]
list_b = [7,8,9]
nama_a = 'aran'
nama_b = 'aran'

print('a adalah b:', a is b)
print('a bukan b:', a is not b)
print('a adalah c:', a is c)
print('b adalah c:', a is c)
print('c bukan d:', c is not d)

umur = int(input("umur mu berapa?"))
if umur>=18 : 
    print("boleh")
elif umur >=15 :
    print("oke")
else :
    print("pulang")     
    

nama1 = input("masukan nama anda:")
print (f"hallo {nama1}")

nama2 = input("masukan nama anda:")
print("halo", nama2)

username = input("buat username:")
password = input("buat passsword:")
print(" \n", username, password)