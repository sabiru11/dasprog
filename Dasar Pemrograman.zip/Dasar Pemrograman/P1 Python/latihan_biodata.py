nama = 'Nurhanifa a.k.a kaka'
umur = '18 tahun'
nim = 'j0403261007'
tinggi_badan ='164cm'
kelas = 'B1'
print(nama)
print(umur)
print(nim)
print(tinggi_badan)
print(kelas)