p = 25
l = 30
Luas = p*l
print(Luas)