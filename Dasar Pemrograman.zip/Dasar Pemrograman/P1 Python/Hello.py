print("Hello World!")
ibu_kota = 'Jakarta'
print(ibu_kota)
a = 5 
b = 2 
c = a + b 
print(c)
p = 20
l = 4 
luas = p*l
print(luas)
s = 5**2 
print(s)

for i in  range(5):
    print("jakarta")
a = 5; b = 2; c = a*b 
print(c)

a = 8 
if a > 5 :
    print('nilai a lebih dari 5')
