#nama = "kian"
#print("nama saya ", nama)
nama = input("siapa nama anda? ")
print("halo", nama)