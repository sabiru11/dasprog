#i = 1 
#while i <= 5 :
    #print(i)
    #i += 2
#password = ""
#while password != 261107:
    #password = int(input("masukan password: "))
    #if password != 261107:
        #print("password salah")
#print ("password benar")

#jawaban = ""
#while jawaban != "ikan hiu":
    #jawaban = input("masukan jawaban: ")
    #if jawaban != "ikan hiu":
        #print("jawaban salah")
#print("jawaban benar")


