warna = ["biru","ungu","hijau","merah"]
warna[2]='pyphone'
warna.append('maroon5')
warna.insert(1,'hitam')
print(warna)

judul_lagu = ['love me not','snowman','superficial love','lovers rock']
print(judul_lagu)
judul_yang_dihapus = judul_lagu.pop()
print("judul lagu yang dihapus: ", judul_yang_dihapus)
print(judul_lagu)

musik = ['RuthB','Slank','Dewa19','MCR','A7X']
musik.remove("Slank")
print(musik)

