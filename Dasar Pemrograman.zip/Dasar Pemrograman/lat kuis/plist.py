nama = input("masukan nama: ")
jumlah = int(input("masukan jumlah nilai: "))

nilai = []

for i in range (jumlah):
    x = int(input(f"nilai ke-{i+1}: "))
    nilai.append(x)

total = 0
for x in nilai:
    total += x 

rata_rata = total/len(nilai) 

if rata_rata 
