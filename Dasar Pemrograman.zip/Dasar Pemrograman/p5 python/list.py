list_nilai = [90, 80, 70, 60, 50]
#print(list_nilai[0:3])
#print(list_nilai[-1:-6:-1])
#list_nilai[2]=5
#print(list_nilai[0:6])
#list_nilai.append(99)
#ist_nilai.insert(2, 99)
#print(list_nilai)

surprise = ["Groucho", "Chico", "Harpo"]

surprise[-1] = surprise[-1].lower()
surprise[-1] = surprise[-1][::-1]
surprise[-1] = surprise[-1].upper()

print(surprise)


