for i in range(1,6):
    print(i)
for i in range(5):
    print("hello")

listkota = ['padang', 'klaten', 'boyolali', 'cibinong', 'depok']

for index, kota in enumerate(listkota, start=1):
    print(index, kota)
