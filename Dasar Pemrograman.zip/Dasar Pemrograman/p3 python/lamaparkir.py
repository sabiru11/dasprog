print("TARIF PARKIR")
print("1.mobil")
print("2.motor")

jenis=int(input("pilih jenis kendaraan = "))
jam=int(input("lama parkir (jam) = "))

if jenis == 1:
    if jam <= 1:
        biaya=5000
    else:
        biaya=5000 + (jam-1)*2000
    print("biaya parkir = ", biaya)
if jenis == 2:
    if jam <= 1:
        biaya=2000
    else:
        biaya=2000 + (jam-1)*1000
    print("biaya parkir = ", biaya)
else:
    print("jenis yang dipilih tidak tersedia")