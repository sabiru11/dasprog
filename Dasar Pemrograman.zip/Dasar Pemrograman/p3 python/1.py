nilai = int(input("masukan nilai"))

if nilai >= 90 :
    print("A")
elif nilai >= 80 :
    print("B")
elif nilai >= 60 :
    print("C")
else :
    print("D")     