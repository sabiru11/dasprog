print("KALKULATOR BANGUN DATAR")
print('1.luas lingkaran')
print('2.keliling lingkaran')
print('3.luas persegi panjang')
print('4.keliling persegi panjang')
print('5.luas segitiga')
print('6.keliling segitiga')
pilihan = int(input("pilihan hitungan = "))
if pilihan == 1:
    phi = 3.14
    r = float(input("jari-jari = "))
    hasil = phi*r*r 
    print("hasil =", hasil)
elif pilihan == 2:
    phi = 3.14
    r = float(input("jari-jari = " ))
    hasil = 2*phi*r
    print("hasil =", hasil)
elif pilihan == 3:
    panjang = float(input("panjang = "))
    lebar = float(input)
    hasil = panjang*lebar
    print("hasil = ", hasil)
elif pilihan == 4:
    panjang = float(input("panjang = "))
    lebar = float(input("lebar = "))
    hasil = 2*(panjang+lebar)
    print("hasil = ", hasil)
elif pilihan == 5:
    alas = float(input("alas = "))
    tinggi = float(input("tinggi = "))
    hasil = 0.5*alas*tinggi
    print("hasil", hasil)
elif pilihan == 6:
    sisia = float(input("sisi a = "))
    sisib = float(input("sisi b = "))
    sisic = float(input("sisi c = "))
    hasil = sisia+sisib+sisic
    print("hasil", hasil)
else:
    print("pilihan tidak tersedia")