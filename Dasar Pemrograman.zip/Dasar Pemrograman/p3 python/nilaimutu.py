print("PEMBERIAN NILAI MUTU")
nilai = float(input("masukan nilai = "))
if nilai >=85:
    print("A")
elif nilai >=75:
    print("B")
elif nilai >=60:
    print("C")
elif nilai >=40:
    print("D")
else:
    print("E")