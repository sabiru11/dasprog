sakit = False
if sakit :
    print("pulang")
if not sakit :
    print("lanjut")