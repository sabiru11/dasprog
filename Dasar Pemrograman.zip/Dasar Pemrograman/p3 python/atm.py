saldo=100000
pin=261107

pin_atm=int(input("masukan pin ATM : "))
if pin_atm == pin:
    print("1.ambil uang")
    print("2.sisa saldo")

    menu = int(input("pilihan menu= "))
    if menu == 1:
        nominal= int(input("nominal uang yang diambil = "))

        if nominal <=saldo:
            saldo= saldo-nominal
            print("sisa saldo=", saldo)
        else:
            print("saldo tidak cukup")
    elif menu == 2:
        print("saldo anda = ", saldo)
    else:
        print("menu tidak tersedia")
else:
    print("pin anda salah")
    