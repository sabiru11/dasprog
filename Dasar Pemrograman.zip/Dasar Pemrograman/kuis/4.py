nama = input("masukan nama anda = ")
tugas = int(input("nilai tugas = "))
uts = int(input("nilai UTS = "))
uas = int(input("nilai UAS = "))
nilai= (tugas*30/100)+(uts*30/100)+(uas*30/100)
print("nilai akhir =", nilai)
if nilai >= 85 :
    grade = "A"
elif nilai >= 75 :
    grade = "B"
elif nilai >= 65 :
    grade = "C"
elif nilai >= 50 :
    grade = "D"
else :
    grade = "E"
print("Grade = ", grade)
if grade in [ "A", "B", "C"]:
    print("LULUS")
else:
    print("TIDAK LULUS")
