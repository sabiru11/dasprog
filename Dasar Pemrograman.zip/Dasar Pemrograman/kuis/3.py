usn=input("masukan username = ")
point= int(input("masukan jumlah point = "))
if point >=4000:
    print("diamond")
elif point >=3000:
    print("platinum")
elif point >=2000:
    print("gold")
elif point >=1000:
    print("silver")
elif point >=0:
    print("bronze")
else :
    print("bermain untuk mendapat point")
