nama = input("masukan nama anda : ")
barang_1= input("nama barang : ")
harga_1= int(input("harga barang : "))
jumlah_1= int(input("jumlah barang : "))
subtotal_1= harga_1*jumlah_1
print("subtotal 1: ",subtotal_1)
barang_2= input("nama barang 2 : ")
harga_2= int(input("harga barang 2 : "))
jumlah_2= int(input("jumlah barang 2 : "))
subtotal_2= harga_2*jumlah_2
print("subtotal 2 : ", subtotal_2)
barang_3= input("nama barang 3 : ")
harga_3= int(input("harga barang 3 : "))
jumlah_3= int(input("jumlah barang 3 : "))
subtotal_3= harga_3*jumlah_3
print("subtotal 3 : ", subtotal_3)
total= subtotal_1+subtotal_2+subtotal_3
print("total = ", total)
uang= int(input("jumlah uang yang dibayarkan : "))
if uang >= total:
    kembalian=uang-total
    print("kembalian = ", kembalian)
else:
    print("pas")
print("nama pembeli = ", nama)
print("total pembelian = ", total)
print("jumlah uang yang dibayar", uang)
print("kembalian = ", kembalian)
print(f"terimakasih {nama}")
