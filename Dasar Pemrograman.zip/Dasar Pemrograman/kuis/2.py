nama = 'bian'
gaji_pokok = 4000000
jumlah_jam_lembur = 12
upah_lembur= 200000
tunjangan= 300000
pajak = 5
print("slip gaji")
print(nama)
gaji_kotor=gaji_pokok+tunjangan+(jumlah_jam_lembur*upah_lembur)
print("gaji kotor = ", gaji_kotor)
total_pajak= gaji_kotor*5/100
print("pajak = ",total_pajak)
gaji_bersih= gaji_kotor-total_pajak
print("gaji bersih = ",gaji_bersih)